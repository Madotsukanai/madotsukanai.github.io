@echo off
set /p "OLD_FILE=実行ファイルのパス: "
set "OLD_FILE=%OLD_FILE:"=%"

.\xdelta3.exe -d -s "%OLD_FILE%" patchwin.vcdiff satsuki.exe

pause
