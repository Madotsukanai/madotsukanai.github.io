#!/bin/bash

read -p "古いファイルのパス: " OLD_FILE

# パスに含まれる引用符（" または '）を除去
OLD_FILE=$(echo "$OLD_FILE" | tr -d '"' "'")

# ファイルの存在チェック
if [ ! -f "$OLD_FILE" ]; then
    echo "エラー: '$OLD_FILE' が見つかりません。"
    exit 1
fi

# SHA-256ハッシュの取得
HASH=$(sha256sum "$OLD_FILE" | awk '{print $1}')

echo "ファイルのSHA-256: $HASH"

# ハッシュ判定と適用パッチの割り当て
case "$HASH" in
    "50ad9db88dcedc99a60205c09bb3f26a66bbfbf2cab6cc0609c65948ecaf68bb")
        PATCH="patchappimage1.vcdiff"
        ;;
    "81b37441265a25bee55d112698f13c8c3e902973f8db31e00598a4669c058d79")
        PATCH="patchappimage2.vcdiff"
        ;;
    *)
        echo "エラー: 対象外のファイルバージョンです。"
        exit 1
        ;;
esac

echo "$PATCH を適用しています..."
xdelta3 -d -f -s "$OLD_FILE" "$PATCH" "satsukibare_0.1.2_amd64.AppImage"

if [ $? -eq 0 ]; then
    echo "パッチの適用が正常に完了しました。"
    chmod +x "satsukibare_0.1.2_amd64.AppImage"
else
    echo "エラー: パッチ適用に失敗しました。"
    exit 1
fi
