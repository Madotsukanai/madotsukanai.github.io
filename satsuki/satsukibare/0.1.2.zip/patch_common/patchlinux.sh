#!/bin/bash

read -p "古いファイルのパス [/usr/bin/satsuki]: " OLD_FILE
OLD_FILE="${OLD_FILE:-/usr/bin/satsuki}"

# ファイルが存在するか確認
if [ ! -f "$OLD_FILE" ]; then
    echo "エラー: '$OLD_FILE' が見つかりません。"
    exit 1
fi

# SHA-256ハッシュの取得
HASH=$(sha256sum "$OLD_FILE" | awk '{print $1}')

echo "ファイルのSHA-256: $HASH"

# ハッシュ値による判定とパッチファイルの決定
case "$HASH" in
    "c7e62a68cd9496e234bc13b034e33f669c1a162164384a500b40fa661ea39f10")
        PATCH="patchlinux1.vcdiff"
        ;;
    "d47ad552818df7d39bdca842e88ffc4ace39b00f5f31aa30c959e40efa80eadd")
        PATCH="patchlinux2.vcdiff"
        ;;
    "9e7282b8a3761fe0c49e366c13b33b395d91b3a9841833a2e9deb1e3f26356ef")
        PATCH="patchlinux3.vcdiff"
        ;;
    *)
        echo "エラー: 対象外のファイルバージョンです。"
        exit 1
        ;;
esac

echo "$PATCH を適用しています..."
xdelta3 -d -f -s "$OLD_FILE" "$PATCH" "satsuki_0.1.2"

if [ $? -eq 0 ]; then
    echo "パッチの適用が正常に完了しました。"
else
    echo "エラー: パッチ適用に失敗しました。"
    exit 1
fi
