@echo off
setlocal enabledelayedexpansion

set /p "OLD_FILE=実行ファイルのパス: "
set "OLD_FILE=%OLD_FILE:"=%"

if not exist "%OLD_FILE%" (
    echo [エラー] 指定されたファイルが存在しません。
    pause
    exit /b
)

:: SHA-256ハッシュの取得
set "HASH="
for /f "skip=1 tokens=*" %%A in ('certutil -hashfile "%OLD_FILE%" SHA256 ^| findstr /v "CertUtil"') do (
    if not defined HASH set "HASH=%%A"
)

:: 空白の除去（小文字比較用）
set "HASH=%HASH: =%"

echo ファイルのSHA-256: %HASH%
echo.

:: ハッシュ判定と適用パッチの割り当て
set "PATCH="
if /i "%HASH%"=="87d6591bd2b87fe61949e2aa2460f5d20063889db78f98efa3dbad588f25720b" set "PATCH=patchwin1.vcdiff"
if /i "%HASH%"=="5c2aaeb9b06e0655cc2855265f1bbad4d287b27143e4b649b0f1b995575c6d24" set "PATCH=patchwin2.vcdiff"
if /i "%HASH%"=="c3f414ad227ed60943a839ba113b3332c9cf0460b9390c1922476bf42f6951dd" set "PATCH=patchwin3.vcdiff"

:: 該当するハッシュがない場合
if not defined PATCH (
    echo [エラー] 対象外のファイルバージョンです。パッチ処理を中止します。
    pause
    exit /b
)

echo %PATCH% を適用しています...
.\xdelta3.exe -d -f -s "%OLD_FILE%" "%PATCH%" satsuki_0.1.2.exe

if %ERRORLEVEL% equ 0 (
    echo [成功] パッチの適用が正常に完了しました。
) else (
    echo [エラー] パッチ適用に失敗しました。
)

pause
