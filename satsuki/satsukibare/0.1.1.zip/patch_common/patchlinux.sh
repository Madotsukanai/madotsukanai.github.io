#!/bin/bash
read -p "古いファイルのパス [/usr/bin/satsuki]: " OLD_FILE
OLD_FILE="${OLD_FILE:-/usr/bin/satsuki}"

xdelta3 -d -f -s "$OLD_FILE" patchlinux.vcdiff satsuki
