#!/bin/bash
read -p "古いファイルのパス: " OLD_FILE

xdelta3 -d -f -s "$OLD_FILE" patchappimage.vcdiff "satsukibare_0.1.1_amd64.AppImage"
